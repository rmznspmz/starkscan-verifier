[![Repository](https://img.shields.io/badge/github-dusk--wallet-purple?logo=github)](https://github.com/dusk-network/wallet-cli)
![Build Status](https://github.com/dusk-network/wallet-cli/workflows/Continuous%20integration/badge.svg)
[![Documentation](https://img.shields.io/badge/docs-dusk--wallet-orange?logo=rust)](https://docs.rs/dusk-wallet/)

# Dusk Wallet

Library providing functionalities to create wallets compatible with Dusk Network

This library is used to implement the official [Dusk CLI wallet](https://github.com/dusk-network/wallet-cli/blob/main/src/bin/README.md).
